package de.mpicbg.tds.knime.blabla;

import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeFactory;
import org.knime.core.node.NodeView;

/**
 * <code>NodeFactory</code> for the "FooBar" Node.
 * document me!
 *
 * @author Max Planck Institute of Molecular Cell Biology and Genetics (MPI-CBG)
 */
public class FooBarNodeFactory 
        extends NodeFactory<FooBarNodeModel> {

    /**
     * {@inheritDoc}
     */
    @Override
    public FooBarNodeModel createNodeModel() {
        return new FooBarNodeModel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNrNodeViews() {
        return 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeView<FooBarNodeModel> createNodeView(final int viewIndex,
            final FooBarNodeModel nodeModel) {
        return new FooBarNodeView(nodeModel);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasDialog() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeDialogPane createNodeDialogPane() {
        return new FooBarNodeDialog();
    }

}

